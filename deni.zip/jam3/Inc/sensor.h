#include "stm32f1xx_hal.h"

#include "stdbool.h"
#include "main.h"
#ifndef SENSOR_H_
#define SENSOR_H_
uint8_t Mode(void);
uint8_t Advance(void);



#endif /* SENSOR_H_ */
